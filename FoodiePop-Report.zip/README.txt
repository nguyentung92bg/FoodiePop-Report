Mo LevelDesign.html de doc bao cao. Chi tiet level: Levels/Levels.html.
Giu nguyen cau truc thu muc. Bao cao HTML offline, khong can cai dat.
